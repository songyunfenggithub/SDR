
from fx2load import *

openfx2(0x04b4, 0x8613)
reset_bix('build/bulkloop.bix')
