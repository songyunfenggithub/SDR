/** \file lights_geeetech.h
 * macros for turning lights on the Geeetech FX2LP development board on and off.
 *
 * The LEDs on this board are connected to PA0 and PA1, which are bits in SFR
 * 0x80
 **/

#ifndef LIGHTS_GEETECH_H
#define LIGHTS_GEETECH_H

#include "fx2types.h"

// Geeetech FX2 Dev board lights
#define D2ONH #0x88 // assembly high byte of light addr 
#define D2OFFH #0x80 
#define D3ONH #0x98 
#define D3OFFH #0x90 
#define D4ONH #0xA8 
#define D4OFFH #0xA0 
#define D5ONH #0xB8 
#define D5OFFH #0xB0 
volatile __xdata __at 0x8800 BYTE D2ON;
volatile __xdata __at 0x8000 BYTE D2OFF;
volatile __xdata __at 0x9800 BYTE D3ON;
volatile __xdata __at 0x9000 BYTE D3OFF;
volatile __xdata __at 0xA800 BYTE D4ON;
volatile __xdata __at 0xA000 BYTE D4OFF;
volatile __xdata __at 0xB800 BYTE D5ON;
volatile __xdata __at 0xB000 BYTE D5OFF;

/**
 * Easier to use macros defined below 
**/
#define activate_light(LIGHT_ADDR) __asm \
 mov __XPAGE, LIGHT_ADDR \
 __endasm; __asm \
 movx a, @r0 \
__endasm \

/**
 *  Easy to make lights blink with these macros:
 *  \code
 *      WORD ct=0;
 *      BOOL on=FALSE;
 *      while (TRUE) {
 *          if (!ct) {
 *              on=!on;
 *              if (on) d2on(); else d2off();
 *          }
 *          ++ct;
 *      }
 *  \endcode
 **/
#define d2on() activate_light(D2ONH)
#define d2off() activate_light(D2OFFH)
#define d3on() activate_light(D3ONH)
#define d3off() activate_light(D3OFFH)
#define d4on() activate_light(D4ONH)
#define d4off() activate_light(D4OFFH)
#define d5on() activate_light(D5ONH)
#define d5off() activate_light(D5OFFH)

#endif
