#ifndef GPIF_DAT_H
#define GPIF_DAT_H

extern const char __xdata WaveData[128];
extern const char __xdata FlowStates[36];
extern const char __xdata InitData[7];

#endif
