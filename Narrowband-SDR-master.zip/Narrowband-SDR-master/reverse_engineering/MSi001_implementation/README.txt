These pictures of an existing dongle based around the MSi001 are sourced
from http://blog.palosaari.fi/2013/10/naked-hardware-13-logitec-ldt-1s310uj.html
