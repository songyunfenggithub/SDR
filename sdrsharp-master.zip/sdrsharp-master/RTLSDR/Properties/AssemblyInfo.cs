﻿using System.Reflection;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("RTL-SDR Controller")]
[assembly: AssemblyDescription("USB interface for RTL2832U based DVB-T dongles")]
[assembly: AssemblyProduct("SDR#")]
[assembly: AssemblyCopyright("Copyright © Youssef TOUIL 2012")]
