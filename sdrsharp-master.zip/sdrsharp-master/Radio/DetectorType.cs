﻿namespace SDRSharp.Radio
{
    public enum DetectorType
    {
        NFM,
        WFM,
        AM,
        DSB,
        LSB,
        USB,
        CW,
        RAW
    }
}
