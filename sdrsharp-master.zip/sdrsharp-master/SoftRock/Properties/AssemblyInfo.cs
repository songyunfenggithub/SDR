﻿using System.Reflection;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("SoftRock Si570 Controller")]
[assembly: AssemblyDescription("SoftRock Si570 Controller")]
[assembly: AssemblyProduct("SDR#")]
[assembly: AssemblyCopyright("Copyright © Youssef TOUIL 2011")]
