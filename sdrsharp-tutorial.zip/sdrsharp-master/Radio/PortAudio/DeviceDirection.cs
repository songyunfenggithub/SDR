﻿namespace SDRSharp.Radio.PortAudio
{
    public enum DeviceDirection
    {
        Input,
        Output,
        InputOutput
    }
}
